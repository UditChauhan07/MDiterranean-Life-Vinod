import React,{useState} from 'react'
import Styles from './Styles.module.scss'

function index() {
  const allProducts = [
    {
      id: 1,
      name: 'Ferragamo shoe',
      description: 'Made in Italy',
      price: 540,
      rating: 4.6,
      imageUrl: '/package/MainImg1.png',
    },
    {
      id: 1,
      name: 'Ferragamo shoe',
      description: 'Made in Italy',
      price: 540,
      rating: 4.6,
      imageUrl: '/package/MainImg1.png',
    },
    {
      id: 1,
      name: 'Ferragamo shoe',
      description: 'Made in Italy',
      price: 540,
      rating: 4.6,
      imageUrl: '/package/MainImg1.png',
    },
    // Add more product objects as needed
  ];// Your array of products

  // Pagination state
  const itemsPerPage = 4; // Number of items per page
  const [currentPage, setCurrentPage] = useState(1);

  // Calculate the range of items to display based on the current page
  const startIndex = (currentPage - 1) * itemsPerPage;
  const endIndex = startIndex + itemsPerPage;
  const currentProducts = allProducts.slice(startIndex, endIndex);

  // Function to handle page change
  const handlePageChange = (newPage) => {
    setCurrentPage(newPage);
  };
  return (
    <div>
 <div>
 <div className={Styles.container}>
 <div className={Styles.MainProductList}>
  {currentProducts.map((product, index) => (
    <div key={index} className={Styles.MainImgControl}>
      <div className={Styles.Control1}>
        <div className={Styles.ControlI}>
          <img src={product.imageUrl} alt={product.name} />
        </div>

        <div className={Styles.ImgcontentAA}>
          <div className={Styles.ImgContent}>
            <div className={Styles.InnerA}>
              <h2>{product.name}</h2>
              <p>{product.description}</p>
              <p>
                <span>${product.price}</span>
              </p>
            </div>

            <div className={Styles.InnerB}>
              <p>
                <img src='/package/GoldenStar.svg' alt="Star" /> {product.rating}
              </p>
              <div>
                <button>Add to Cart</button>
              </div>
            </div>
          </div>
        </div>
      </div>


      
    </div>
  ))}
</div>
</div>

      {/* Pagination controls */}
      <div className={Styles.Pagination}>
        {/* Previous page button */}
        <button
          onClick={() => handlePageChange(currentPage - 1)}
          disabled={currentPage === 1}
        >
          Previous
        </button>

        {/* Display current page and total pages */}
        <span>{`Page ${currentPage} of ${Math.ceil(allProducts.length / itemsPerPage)}`}</span>

        {/* Next page button */}
        <button
          onClick={() => handlePageChange(currentPage + 1)}
          disabled={endIndex >= allProducts.length}
        >
          Next
        </button>
      </div>
    </div>
  




      <section>
        <div className={Styles.container}>
          <div className={Styles.MainProductList}>

          <div className={Styles.MainProductListA}>
            <div className={Styles.MainImgControl}>
              <div className={Styles.Control1}>
                <div className={Styles.ControlI}>
                  <img src="/package/MainImg1.png"/>
                </div>

                <div className={Styles.ImgcontentAA}>
                <div className={Styles.ImgContent}>

                <div className={Styles.InnerA} >
                    <h2>Ferragamo shoe</h2>
                    <p>Made in Italy</p>
                    <p><span>$540</span></p>
                  </div>

                  <div className={Styles.InnerB} >
                    
                    <p><img src='/package/GoldenStar.svg'/>  4.6</p>
                    <div><button>Add to Cart</button></div>
                  </div>
                </div>
                </div>
              </div>
             
              <div className={Styles.Control1}>
              <div className={Styles.ControlI}>
                  <img src="/package/MainImg1.png"/>
                </div>

                <div className={Styles.ImgcontentAA}>
                <div className={Styles.ImgContent}>
                  <div className={Styles.InnerA} >
                    <h2>Ferragamo shoe</h2>
                    <p>Made in Italy</p>
                    <p><span>$540</span></p>
                  </div>

                  <div className={Styles.InnerB}>
                    
                    <p><img src='/package/GoldenStar.svg'/>  4.6</p>
                    <div><button>Add to Cart</button></div>
                  </div>
                </div>
                </div>
              </div>

            </div>


            <div className={Styles.MainImgControl}>
              <div className={Styles.Control1}>
                <div className={Styles.ControlI}>
                  <img src="/package/MainImg1.png"/>
                </div>

                <div className={Styles.ImgcontentAA}>
                <div className={Styles.ImgContent}>

                <div className={Styles.InnerA} >
                    <h2>Ferragamo shoe</h2>
                    <p>Made in Italy</p>
                    <p><span>$540</span></p>
                  </div>

                  <div className={Styles.InnerB} >
                    
                    <p><img src='/package/GoldenStar.svg'/>  4.6</p>
                    <div><button>Add to Cart</button></div>
                  </div>
                </div>
                </div>
              </div>
             
              <div className={Styles.Control1}>
              <div className={Styles.ControlI}>
                  <img src="/package/MainImg1.png"/>
                </div>

                <div className={Styles.ImgcontentAA}>
                <div className={Styles.ImgContent}>
                  <div className={Styles.InnerA} >
                    <h2>Ferragamo shoe</h2>
                    <p>Made in Italy</p>
                    <p><span>$540</span></p>
                  </div>

                  <div className={Styles.InnerB}>
                    
                    <p><img src='/package/GoldenStar.svg'/>  4.6</p>
                    <div><button>Add to Cart</button></div>
                  </div>
                </div>
                </div>
              </div>

            </div>


            <div className={Styles.MainImgControl}>
              <div className={Styles.Control1}>
                <div className={Styles.ControlI}>
                  <img src="/package/MainImg1.png"/>
                </div>

                <div className={Styles.ImgcontentAA}>
                <div className={Styles.ImgContent}>

                <div className={Styles.InnerA} >
                    <h2>Ferragamo shoe</h2>
                    <p>Made in Italy</p>
                    <p><span>$540</span></p>
                  </div>

                  <div className={Styles.InnerB} >
                    
                    <p><img src='/package/GoldenStar.svg'/>  4.6</p>
                    <div><button>Add to Cart</button></div>
                  </div>
                </div>
                </div>
              </div>
             
              <div className={Styles.Control1}>
              <div className={Styles.ControlI}>
                  <img src="/package/MainImg1.png"/>
                </div>

                <div className={Styles.ImgcontentAA}>
                <div className={Styles.ImgContent}>
                  <div className={Styles.InnerA} >
                    <h2>Ferragamo shoe</h2>
                    <p>Made in Italy</p>
                    <p><span>$540</span></p>
                  </div>

                  <div className={Styles.InnerB}>
                    
                    <p><img src='/package/GoldenStar.svg'/>  4.6</p>
                    <div><button>Add to Cart</button></div>
                  </div>
                </div>
                </div>
              </div>

            </div>
          </div>




          <div className={Styles.MainProductListB}></div>

          
          
          </div>


        </div>
      </section>
    </div>
  )
}

export default index